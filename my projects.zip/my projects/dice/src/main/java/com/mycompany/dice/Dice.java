/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dice;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Dice {

    public static void main(String[] args) {
       Scanner inp = new Scanner (System.in);
		
		// swicth statements 
		int choice = 0;

    // 1 = Coffee
    // 2 = Tea
	
	 System.out.print("what would you like to order (1) coffe or (2) tea ");
      choice = inp.nextInt();
    switch (choice) {
		
      case 1:
        System.out.println("You ordered Coffee");
		break;

      case 2:
        System.out.println("You ordered Tea");
		
		break;
		 default:
        System.out.println("Invalid choice");
    }
	
	//while loops
	
	int dice = 1;

while (dice <= 6) {
  if (dice < 6) {
    System.out.println("No Yatzy.");
  } else {
    System.out.println("Yatzy!");
  }
  dice = dice + 1;
}
    }
}
