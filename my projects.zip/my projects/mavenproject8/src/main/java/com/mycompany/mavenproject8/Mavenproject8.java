/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject8;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject8 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        // Declare variables
        int age;
        boolean isStudent;
        double ticketPrice;

        // Input
        System.out.print("Enter your age: ");
        age = keyboard.nextInt();

        System.out.print("Are you a student? (true/false): ");
        isStudent = keyboard.nextBoolean();

        // Determine ticket price
        if (age < 12)
        {
            ticketPrice = 5;
        }
        else if (age >= 65)
        {
            ticketPrice = 7;
        }
        else if (isStudent)
        {
            ticketPrice = 8;
        }
        else
        {
            ticketPrice = 12;
        }

        // Display
        System.out.println("Your final price is: $" + ticketPrice);
    }
}
