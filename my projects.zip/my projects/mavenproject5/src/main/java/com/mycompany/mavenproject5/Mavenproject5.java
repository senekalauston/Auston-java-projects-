/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject5;

import static java.sql.DriverManager.println;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject5 {

    public static void main(String[] args) {
      
       Scanner keyboard = new Scanner("System.in");
		 
		 //declare variables
		 int iAge;
		 double rTicket = 25;
		 double rAmount = 0;
		 
		 //input
		      System.out.println("");
		 iAge = keyboard.nextInt();
		 
		 //declare the ticket price
		
		 
		 //begin the ifs
		 if (iAge < 5)
		 {
			 rAmount = 0 ;
                                
		  if (iAge <= 12)
		 {
			 rAmount = rTicket * 0.5;
		 }
		 
                 else if(iAge <= 12)
		 {
			 rAmount = rTicket;
		 }
		  
		 }
		 
		 //display on screan
		 System.out.println("The amount due is R" + rAmount);
		 
	 }
 }