/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject14;

import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

 class kb {
    
       String name;
       String surname;
       String course;
       int age ;
       String Id;
       
       
       //creating public constructor for class 
       public kb (String name,String surname,String course, int age,String Id ){
           this.surname = surname;
           this.course = course;
           this.name = name;
           this.age = age;
           this.Id = Id;
       }
       
       public String toString (){
        return "Name :" + name +"\n Surname " + surname+ "\n Course " + course + "\n age "+ age +"\n ID " + Id;
       }
       public String getId(){
         return Id;
       }
    
    }
public class Mavenproject14 {
    
  public static Scanner Input = new Scanner(System.in);
  public static HashMap<String ,Kb>profileDatabase = new HashMap<>
    public static void main(String[] args) {
   
    }
    public void capture (){
        System.out.println("*******welcome******");
        
    
    }
    
}
