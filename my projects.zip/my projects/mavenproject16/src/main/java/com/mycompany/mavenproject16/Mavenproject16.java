/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package java.util.Scanner;

/**
 *
 * @author USER
 */
