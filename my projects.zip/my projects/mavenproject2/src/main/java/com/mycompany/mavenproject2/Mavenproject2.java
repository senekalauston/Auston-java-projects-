/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        
       String month1 = "january";
       String month2 = "july";
       Scanner inp = new Scanner(System.in);   
       
        System.out.println("enter month of enrollment january or july ");
        String month = inp.nextLine();
        
        if (month1.equals(month) || month2.equals(month)){
            System.out.println("you have enrolled for month : " + month);
        }
        else 
        {
            System.out.println("you have chosenn an invalid month");
        }
                
    }
}
