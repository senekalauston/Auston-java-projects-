/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.Scanner;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class TestMarks {

    public static void main(String[] args) {
           Scanner keyboard = new Scanner(System.in);
    //declare variables
    char cAnswer;
    double rMark;
    double rPerc;
	final int TESTTOTAL = 60; //The total marks for the test
    
        //input
        System.out.println("Do you want  to enter the marks for the test? <Y/N> ");
        cAnswer = Character.toUpperCase(keyboard.next().charAt(0));
    
    //begin the loop
	while(cAnswer == 'Y')
	{
		System.out.println("What is the mark out of 60?");
		rMark = keyboard.nextDouble();
		
		//processing
		rPerc = rMark / TESTTOTAL * 100;
		//output
		System.out.println("The percentage is : " + rPerc + "%");
		
		System.out.println("Do you want  to enter the marks for the test? <Y/N> ");
		cAnswer = Character.toUpperCase(keyboard.next().charAt(0));
		
		}// end while loop
	
	System.out.println("You are done calculating percentages. ");
		
    }
}
