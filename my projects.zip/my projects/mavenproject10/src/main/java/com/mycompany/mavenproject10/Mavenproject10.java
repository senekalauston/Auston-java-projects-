/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject10;

/**
 *
 * @author USER
 */
public class Mavenproject10 {

    public static void main(String[] args) {
       // System.out.println("Hello World!");
  int iMark = 42;
int iSessionsAttended = 3;
 
if (iMark >= 50 || iSessionsAttended >= 8){
    System.out.println("Pass");
}
else{
    System.out.println("Fail");
}

    }
}
