/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject7;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject7 {

    public static void main(String[] args) {
        
      String student;
      int age ;
      double price4ticket = 0;
      boolean isStudent = true;
      
      //getting user input 
      JOptionPane.showMessageDialog(null," welcome to the movies ");
      age = Integer.parseInt(JOptionPane.showInputDialog(null, " Enter cuatomer age "));
      student = JOptionPane.showInputDialog(null," Are a student yes or no  ");
      //checking if the customer qualifies for the ticket
      
      if ( age <= 12 ){
       //calculate ticket price for children
       price4ticket = 5.00;
      }
      else if (age >12 && age <65){
            price4ticket = 12.00;
      }
      else if (age >= 65){
        price4ticket = 7.00;
      }
      
      
      else {
       JOptionPane.showMessageDialog(null,"  wrong input ");
      }
      JOptionPane.showMessageDialog(null," Ticket price " + price4ticket);
    }
}
