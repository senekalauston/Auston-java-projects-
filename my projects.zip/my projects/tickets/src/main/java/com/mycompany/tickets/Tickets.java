/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tickets;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Tickets {

    public static void main(String[] args) {
        
        int soldstudent,soldlecture ,tot;
        int ticketforlecturer;
        int ticketforstudents;
        int ToTofTicketsold;
        int ticketsalespayment;
        
      soldstudent = Integer.parseInt(JOptionPane.showInputDialog(null, "how many student tickets did you sell "));
      soldlecture = Integer.parseInt(JOptionPane.showInputDialog(null, "how many lecture tickets did you sell "));
      
      ticketforlecturer = soldlecture * 60;
      ticketforstudents = soldstudent * 50;
      
      tot = soldlecture + soldstudent;
      ToTofTicketsold = ticketforlecturer + ticketforstudents ;
      
      if (soldstudent > 20 && soldlecture > 10 ){
        
         ticketsalespayment =  (int) (ToTofTicketsold *1.12);
      }
      
      else {
        ticketsalespayment =  (int) (ToTofTicketsold *1.10);
      }
      
      JOptionPane.showMessageDialog(null, "tickets sold " + "student tickets " + soldstudent + 
              "\nLeture tickets " + soldlecture + "\n Totalnumber of tickets sold " + tot+ "\n Total Sales " + ToTofTicketsold
          + " payment to be received  R" +  ticketsalespayment);
      
    }
}
