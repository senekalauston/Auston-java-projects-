/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author USER
 */
public class GUI implements ActionListener {
    
      int count = 0;
      JLabel label;
      JFrame frame;
      JPanel panel;
     public GUI(){
         
         //create a frame for your interface 
         
         JFrame frame = new JFrame();
         
         JButton button = new JButton("click me ");
         button.addActionListener(this);
         label = new JLabel("Number of cliks : 0");
         
         panel = new JPanel();
         panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
         panel.setLayout(new GridLayout(0,1));
         panel.add(button);
         panel.add(label);
         
         frame.add(panel, BorderLayout.CENTER);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.setTitle("HELLO THABANG");
         frame.pack();
         frame.setVisible(true);
         
         
     
     }

    public static void main(String[] args) {
        
    //   JOptionPane.showMessageDialog(null, "");
       new GUI();
      
       
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       count++;
       label.setText("Number of clicks " + count);
    }
}
