/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject11;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject11 {
 
    public static void main(String[] args) {
         Scanner keyboard = new Scanner(System.in);   
        double PI = 3.142;
        char cShape;
        double rSize = 0, rArea = 0;
        boolean bShapeValid = false;
        boolean bSizeValid = false;
        
        // getting input 
        System.out.println("Enter the shape (C for Circle ,S for Square , T for Triangle)");
        cShape = keyboard.next().toUpperCase().charAt(0);
        
        if (cShape == 'C'  ){
            bShapeValid  = true;
        }
        else if (cShape == 'S'){
          bShapeValid  = true;
        }
        else if (cShape == 'T'){
        bShapeValid  = true;                
        }
        else 
        {
            System.out.println("wrong input ");
        }
         System.out.println("Enter positive  number ");
         rSize = keyboard.nextDouble();
         
         if (rSize >0){
             bSizeValid = true;
         }
         
         if (bShapeValid && bSizeValid ){
            
             switch (cShape){
                    
                 case 'C':
                     rArea = PI * rSize* rSize;
                     break;
                 case 'S':
                     rArea = rSize *rSize;
                     break;
                 case 'T' :
                     rArea = 0.5 * rSize *rSize;
                     break;
             }
             System.out.println("Area is : " + rArea); 
         }
         else {
             System.out.println("Ivalid input please input valid shape and number "); 
         }
    }
}
