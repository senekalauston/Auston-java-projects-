/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject19;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class kb {
  public void student (){
  
      
      int mark,totalmark = 0;
        int numberofstudents;
        int counterstudents = 0;
        int counterpass = 0,counterfail = 0;
        double avarage;
        
      // getting the number of students to capture 
        
     numberofstudents = Integer.parseInt( JOptionPane.showInputDialog(null," how many students would like capture marks for "));    
        for (int i = 0; i < numberofstudents ; i++){
            
          mark  = Integer.parseInt( JOptionPane.showInputDialog(null," Enter marks for student  " + (i+1)));
          counterstudents += 1;
          totalmark += mark;
          
          if (mark >= 70 ){
              JOptionPane.showMessageDialog( null, "Distinction Pass");
              counterpass += 1;
          }
          else if (mark < 70 && mark > 50){
            JOptionPane.showMessageDialog( null, "Pass");
            counterpass += 1;
          }
          else {
            JOptionPane.showMessageDialog( null, "fail");
            counterfail += 1;
          }
        }
        avarage = totalmark/counterstudents;
        JOptionPane.showMessageDialog( null, "Number of students who Passed :" + counterpass +"\nNumber of students who Failed :" + counterfail +
                "\nClass Avarage: " + avarage);
  }
    
}
