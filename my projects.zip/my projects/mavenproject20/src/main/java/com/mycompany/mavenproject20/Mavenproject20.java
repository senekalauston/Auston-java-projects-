/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject20;

/**
 *
 * @author USER
 */
public class Mavenproject20 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
