/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practice;

import java.util.HashMap;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */

class Student {
    
    private String  Name;
    private String Id ;
    private int Age ;
    private String Course ; 
   
    public Student (String Name,String Id,int Age,String Course){
    
      this.Name = Name;
      this.Id = Id;
      this.Age = Age;
      this.Course = Course; 
    }
   
 public String toString(){
  
 return "Student ID " + Id + "\n  Name " + Name + "\n AGE " + " \n Course " + Course ;
}
  public String getId() {
        return Id;
    }

}

    
public class Practice {
    
    private static Scanner Scanner = new Scanner(System.in);
    private static HashMap<String ,Student>StudentDatabase = new HashMap<>();
    
    public static void main(String[] args) {
        
      int choice;
      do{
          choice = Integer.parseInt(JOptionPane.showInputDialog(null,"****Student apllication*****  " + "\n 1) Capture "+
                "\n 2) Search student" + "\n 3) Display all students" + "\n 4) EXIT " +
                "\n "));
       switch (choice)
       {
           case 1 :Capture();
           break;
           case 2 : Search();
           break;
           case 3 : Display();
           break ;
           case 4 : 
             JOptionPane.showConfirmDialog(null, "exiting application ");
             break;
           default :
               JOptionPane.showMessageDialog(null, "Invalid input");
       }
      }while(choice != 4);
    }
    
    public static void Capture(){
    String Name = JOptionPane.showInputDialog(null,"Enter Student Name ");
    String Id = JOptionPane.showInputDialog(null,"Enter Student ID");
    int Age = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter student Age"));
    String Course = JOptionPane.showInputDialog(null,"Enter student course ");
    //create local object
    Student Student = new Student (Id,Name,Age,Course);
    StudentDatabase.put(Id,Student);
    JOptionPane.showMessageDialog(null, "Student successfully Captured ");
    }
    public static void Search(){
    String Id = JOptionPane.showInputDialog(null,"Enter Student Enter Student Id to search ");
    Student Student = StudentDatabase.get(Id);
    if (Student != null){
     JOptionPane.showMessageDialog(null, "*********Student found*********** " + "\n" +Student);
    }
    else {
      JOptionPane.showMessageDialog(null, "Student not found ");
    }
    }
    public static void Display(){
    
        if (StudentDatabase.isEmpty()){
        JOptionPane.showMessageDialog(null, "NO student in data base");
        }
        else {
         for (Student Student : StudentDatabase.values()){
          JOptionPane.showMessageDialog(null, "***********students found students************  " +"\n" + Student+"'\n ");
         }
        }
    }
    
}
