/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject13;

import java.util.Random;

/**
 *
 * @author USER
 */
public class Mavenproject13 {

    public static void main(String[] args) {
     //   System.out.println("Hello World!");
     Random rand = new Random ();
     
     int number1,number2,number3;
     do {
       number1 = rand.nextInt(9)+1;
       number2 = rand.nextInt(9)+1;
       number3 = rand.nextInt(9)+1;
     }
     while (number1 == number2 || number1 == number2 || number2 == number3);
        System.out.println(" your numbers " + number1 + " " + number2 + " "+ number3 );
    }
}
