/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.Scanner;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class RandomNumber {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    Scanner keyboard = new Scanner(System.in);

		//declare variables
		int iGuess;
		 
		Random rand = new Random();
		int iComputerGenerate = rand.nextInt(100) + 1;
		
		//input
		System.out.println("Guess a number between 1 and 100");
		iGuess = keyboard.nextInt();
		
		if(iGuess != iComputerGenerate)
		{ 
	     while(iGuess > iComputerGenerate)
		 {
			 System.out.println("Your nuumber is too high! ");
		 }
		  System.out.println("Guess a number between 1 and 100");
		            iGuess = keyboard.nextInt();
		 
			 System.out.println("YES-the number is" + iGuess);
		 }
                //output
	    System.out.println("YES-the number is" + iGuess);
    }
	}
  
	

