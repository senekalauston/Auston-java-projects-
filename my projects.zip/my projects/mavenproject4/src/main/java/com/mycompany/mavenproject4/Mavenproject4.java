/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject4;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject4 {

    public static void main(String[] args) {
       String choice;
       String option1 = "A";
       String option2 = "B";
       String option3 = "C";
       double priceforTv;
       int priceperMonth;
       double interest = 74.15/100;
       choice = JOptionPane.showInputDialog(null, "      Select a TV      "
               + "\n A - 32-inch price : R 2 ,499.00" + 
               "\n B - 40-inch price : R 3 ,999.00" + 
               "\n B -55-inch price : R 5,799.00" + 
               " \n Enter your choice ");
         
       if (choice.equals(option1))
       {
           priceforTv = 2499.00;
           priceperMonth = (int)(priceforTv +(priceforTv * interest))/24;
           System.out.println(" pay as little as R  " + priceperMonth);
       }
       if (choice.equals(option2)){
           
           priceforTv = 3999.00;
           priceperMonth = (int)(priceforTv +(priceforTv * interest))/24;
           System.out.println(" pay as little as R  " + priceperMonth);
       }
       if (choice.equals(option3)){
           
           priceforTv = 5799.00;
           priceperMonth = (int)(priceforTv +(priceforTv * interest))/24;
           System.out.println(" pay as little as R  " + priceperMonth);
       }
       else {
           System.out.println("invalid input ");
       }
    }
}
