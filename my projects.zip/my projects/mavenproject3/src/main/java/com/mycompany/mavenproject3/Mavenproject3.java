/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject3;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;


/**
 *
 * @author USER
 */
public class Mavenproject3 {

    public static void main(String[] args) {
      	Scanner keyboard = new Scanner(System.in);
		
		//Constant
		final double INTEREST_CHARGED = 0.7415;
		
		//declare vaiables
		double A = 2499.00,B = 3999.00,C = 5799.00;
		
		System.out.print("        Select a TV:    ");
		System.out.print("Your optons are: " +"\n 32-inch TV Price = R2,499.00" + "/n 40-inch TV Price = R3,999.00" +"/n 55-inch TV Price = R5,799.00");
		System.out.print("Enter your choice: ");
		String choice1 = keyboard.nextLine();
		
		//format currency values
		DecimalFormat  currency = new DecimalFormat ("R#,###.00");
	    System.out.println(currency.format(A));
	    System.out.println(currency.format(B));
		System.out.println(currency.format(C));
    }
}
