/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.beefit;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class BEEFIT {

    public static void main(String[] args) {
        
        double BodyMass ,height;
        double BMI ;
        
        
        do {
             BodyMass = Double.parseDouble(  JOptionPane.showInputDialog(null,"Enter Body Mass in KG or press 0 to Terminate the program"));
             height  = Double.parseDouble(  JOptionPane.showInputDialog(null,"Enter Body Mass in KG or press 0 to Terminate the program"));
             BMI = BodyMass/height;
             
             
            }
        while ( BodyMass != 0);
        
    }
}
