/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practice11;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Practice11 {

    public static void main(String[] args) {
      
       
       
       int numberofShirts ;
       double priceperShirt =50,subtotal;
       double discount = 0.2,pricediscount,payable;
       
      numberofShirts = Integer.parseInt(JOptionPane.showInputDialog(null,"how many shirts did you buy ?? "));
      subtotal = numberofShirts*priceperShirt;
      if (subtotal > 200){
       pricediscount = discount* priceperShirt;
       payable = subtotal -  pricediscount ;
      }
      else {
       payable = subtotal;
      }
      
      JOptionPane.showMessageDialog(null, "*********receipt***********" + "\n"
              + "Number of shirts bought : " + numberofShirts +"\n"
                      + "price per shirt : R" + priceperShirt + "\n"
                              + "sub total : R" + subtotal + "\n"+ "Total: R" + payable);
    }
}
