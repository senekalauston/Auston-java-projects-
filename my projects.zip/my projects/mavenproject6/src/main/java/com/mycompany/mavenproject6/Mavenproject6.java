/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject6;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject6 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
			//declare variables
			int iAge;
			String sStudent;
			double ticketPrice;
			
			//enter flag
			boolean isStudent = true;
			//input
			System.out.println("Enter your age: ");
			iAge = keyboard.nextInt();
			System.out.print("Are yoou a student? ");
			
			
			//start the if and else
				if (iAge > 12)
				{
					ticketPrice = 5
					
					else if (iAge >= 65)
					{
						ticketPrice = 7
					}
					else if (isStudent)
					{
						ticketPrice = 8
						{
							else 
							{ 
						     ticketPrice = 12
							}
						}
						
						//display
						System.out.println("Your final price is: ");
						
					}
				}
    }
}
