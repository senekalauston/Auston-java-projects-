/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject18;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject18 {

    public static void main(String[] args) {
       Random rand = new Random();
       
       int number1 = rand.nextInt(59)+ 1;
       int number2 = rand.nextInt(59)+ 1;
       int number3 = rand.nextInt(59)+ 1;
       int number4 = rand.nextInt(59)+ 1;
       int number5 = rand.nextInt(59)+1;
       
       int[]betnumber = new int[5];
       
       for (int i = 0;i <betnumber.length;i++)
           
       betnumber[i]= Integer.parseInt( JOptionPane.showInputDialog(null,"select a your "+betnumber[i+1]+" lucky number between 1 and 60 "));
       
      if ( betnumber.length != number1 || betnumber.length != number2 || betnumber.length != number3 || betnumber.length != number4 || betnumber.length != number5){
         JOptionPane.showMessageDialog(null, "numbers are winning numbers are " + number1 + " , " + number2 + " , " + number3 + " , " 
         + number4 + " ,Bonus ball is : " + number5 );
      }
      else {
        JOptionPane.showMessageDialog(null,"you won the lotto jack port ");
      }
       
       }
    }
    
   
    

