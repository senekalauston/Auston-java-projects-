/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject21;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject21 {

    public static void main(String[] args) {
        int NightsPerStay; 
        double AdultsPrice = 200,ChildrenPrice = 100;
        int numberOfadults = 0 , NumberofChildren = 0; 
         double balance ;
        int Choice;
          
        
          NightsPerStay = Integer.parseInt(JOptionPane.showInputDialog(null,"How many nights would you like to spend here ?"));
        do{
            
            Choice = Integer.parseInt( JOptionPane.showInputDialog(null, "****************Menu**************"+ 
                   "\n (1) Add adults"
                   +"\n(2) add children" + 
                    "\n(3) Show Balance" + 
                   "\n(4) Exit"));
           
             balance = NightsPerStay*((numberOfadults *AdultsPrice) + (NumberofChildren *ChildrenPrice));
            switch (Choice){
                case 1:
                    numberOfadults =  Integer.parseInt(JOptionPane.showInputDialog(null,"Number of adults so far :"+ numberOfadults+
                            " \nHow many how many adults do you want to add ?"));;
                  
                    break ;
                case 2:
                    NumberofChildren =  Integer.parseInt(JOptionPane.showInputDialog(null,"Number of Children so far " + NumberofChildren+
                            "\nHow many how many Children  do you want to add ?"));;
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "number of children : " + NumberofChildren +
                            "\nnumber of adults : " + numberOfadults);
                              
            }
             
       }
        while( Choice != 4);
        if (Choice != 1 || Choice != 2 || Choice != 3){
                    
                    
                  Choice = Integer.parseInt( JOptionPane.showInputDialog(null, "Wrong input you should enter integers from 1 to 4 "));
                }
    }
}
