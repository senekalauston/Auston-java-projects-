/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.mycompany.mavenproject17;

/**
 *
 * @author USER
 */
import java.io.*;
import java.util.*;

public class Mavenproject17 {

    public static void main(String[] args) throws IOException {
       Map<String,Integer>counter= new HashMap<>();
        //create an object 
        File file = new File("mytextfile.text");
        Scanner Scanner = new Scanner(file);
        while(Scanner.hasNext()){
        
         String word = Scanner.next().toLowerCase().replaceAll("[^a-z0-9]", "");
         if (word.isEmpty())continue;
         
         //if word is not last one add one if not add coma 
         counter.put(word, counter.getOrDefault(word, 0)+ 1);
        }Scanner.close();
        //print result
        for(String key : counter.keySet()){
            System.out.println("key : " + counter.get(key));
        }
        System.out.println(" words count " + counter.getOrDefault(file, 0));
    }
}
