/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject12;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject12 {

    public static void main(String[] args) {
     //System.out.println("Hello World!");
     Scanner inp = new Scanner(System.in);
     int num1,num2,num3,num4;
     boolean flag1 = false, flag2 = false ,flag3 =false,flag4 = false;
     
        System.out.println("Enter number 1");
        num1 = inp.nextInt();
        System.out.println("Enter number 2");
        num2 = inp.nextInt();
        System.out.println("Enter number 3");
        num3 = inp.nextInt();
        System.out.println("Enter number 4");
        num4 = inp.nextInt();
        
        if (num1%2 != 0)
        {
           flag1 = false;
        }
         if (num2%2 != 0)
        {
           flag2 = false;
        }
          if (num3%2 != 0)
        {
           flag3 = false;
        }
         if (num4%2 != 0)
        {
           flag4 =false;
        }
         
         if (flag1 && flag2 && flag3 && flag4){
             System.out.println("No odd number Found");
         }
         else {
             System.out.println("only even number are found");
         }
    }
}
