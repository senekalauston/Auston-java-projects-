/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.democlass;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Democlass {

    public static void main(String[] args) {
     Scanner keyboard = new Scanner (System.in);  
    int CHOICE =0;
     System.out.println(" 1 DEPOSIT " +"\n2 WIthdraw" + "\n3 check balance" );
     CHOICE = keyboard.nextInt();
    switch (CHOICE)
    {
        case 1 :
            System.out.println("choice: DEPOSIT");
           break;
        case 2:
            System.out.println("choice: Withdraw");
            break;
        case 3:
            System.out.println("choice: check balance");
            break;
        default :
            System.out.println("invalid input");
    }
    
    }
}
