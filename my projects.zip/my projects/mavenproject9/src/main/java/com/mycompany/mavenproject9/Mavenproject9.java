/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject9;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Mavenproject9 {

    public static void main(String[] args) {
     //   System.out.println("Hello World!");
    Scanner keyboard = new Scanner(System.in);
    
    final int Vat = 15,Insure_perc = 11;
    final double PerKG = 5.5, Road  = 0.8,Train = 0.5, Air = 1.5;
    double rMass, rkm,rTotal = 0,rTransport= 0;
    char cTransport,cInsure;
    
    //input 
        System.out.println("Number of Kg to Transport");
        rMass = keyboard.nextDouble();
        System.out.println("Number of KM");
        rkm = keyboard.nextDouble();
        System.out.println("Is the transport by <R>oad , <T>rain or <A>ir");
        cTransport= keyboard.next().charAt(0);
        System.out.println("Insurance <Y>ES or <N>O ");
        cInsure = keyboard.next().charAt(0);
        
        //set the flags 
        
        if (cTransport == 'R')
            rTransport = Road;
        if (cTransport == 'T')
            rTransport = Train;
        if (cTransport == 'A')
            rTransport = Air;
        
        //calculate total cost 
        rTotal = rMass + Insure_perc / 100* rTotal;
        
        //add vat to total 
        rTotal = rTotal + Vat /100 * rTotal;
        
        System.out.println("you will pay: R " + rTotal);
    }
}
