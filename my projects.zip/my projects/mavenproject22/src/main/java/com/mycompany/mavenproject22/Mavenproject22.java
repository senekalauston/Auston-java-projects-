/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject22;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject22 {

    public static void main(String[] args) {
        Random rand = new Random ();
        int number1, randomnumber;
        randomnumber =  rand.nextInt(4)+1;
        int counter = 0;
        
        do{
            
       number1  =Integer.parseInt(JOptionPane.showInputDialog(null,"Enter number to guess "));
       
       if (number1 < randomnumber){
        JOptionPane.showMessageDialog(null, " to low guess again" + "\nnumber is " + randomnumber);
       }
       else if (number1 > randomnumber){
        JOptionPane.showMessageDialog(null, " to high guess again" + "\nnumber is " + randomnumber);
       }
        counter += 1;
        }
       while ( number1 != randomnumber); 
        if (number1 == randomnumber){
        JOptionPane.showMessageDialog(null, " correct guess"+ "\n after " + counter + " Attempts ");
        }
    }
}
