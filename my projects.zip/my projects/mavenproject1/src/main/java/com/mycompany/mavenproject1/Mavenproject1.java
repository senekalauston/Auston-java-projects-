/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        
        int department;
        int oldsalary ,newsalary = 0 ;
       
        oldsalary = Integer.parseInt(JOptionPane.showInputDialog(null, "what is the current salary  "));
        department = Integer.parseInt(JOptionPane.showInputDialog("in what department are you in A = 1 "+
                "\n and department B  = ?"));
        
        if (department == 1){
         newsalary =  (int) ((double) oldsalary * 1.10);  
         
         JOptionPane.showMessageDialog(null, "your old salary was R " + oldsalary
                + "\nyou recived a" +" 10% "+ " increase "+"\n your new slary is R" +  newsalary);
        }
        else if (department == 2){
         newsalary =  (int) ((double) oldsalary * 1.08); 
         
         JOptionPane.showMessageDialog(null, "your old salary was R" + oldsalary
                + "\nyou recived a" +" 8% " +" increase "+"\n your new slary is R" +  newsalary);
        }
        
    }
}
