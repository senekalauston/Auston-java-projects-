/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject23;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class Mavenproject23 {

    public static void main(String[] args) {
        Scanner inp = new Scanner(System.in);
        int positivenumber=0 ,negativenumbers = 0,zoros =0; 
        int integer = 0;
        for (int i =0 ;i < 10;i++){
        integer = Integer.parseInt( JOptionPane.showInputDialog(null, "enter integer numbe : " +(i+1) )); 
           
            if (integer < 0)
            {
            negativenumbers += 1;
            }
            else if (integer > 0 ){
            positivenumber += 1;
            }
            else if (integer <1 && integer >-1 ){
              zoros += 1;
            }   
        }
        JOptionPane.showMessageDialog(null,"Zeros: "+ zoros + 
                    "\nNegative numbers : "+ negativenumbers +
                    "\nPositive numbers : "+ positivenumber );
    }
}
