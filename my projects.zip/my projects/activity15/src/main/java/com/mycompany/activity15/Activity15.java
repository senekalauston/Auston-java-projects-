/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.activity15;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Activity15 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        
        int subjectPercentage [] = new int[6];
        
        for (int i = 0;i < subjectPercentage.length;i++){
            System.out.println("input subject " + (subjectPercentage[i+1]));
        }
       
    }
}
