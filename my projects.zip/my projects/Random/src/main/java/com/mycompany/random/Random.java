/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.random;

import java.util.*;

/**
 *
 * @author USER
 */
public class Random {

    public static void main(String[] args) {
        
    }
}
