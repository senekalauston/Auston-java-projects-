/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject15;

import java.util.Scanner;

/**
 *
 * @author USER
 */
public class Entrance {

    public static void main(String[] args) {
      //  System.out.println("Hello World!");
     Scanner keyboard = new Scanner(System.in );
     
     // declare variables
    String sName, sGender;
    char Male = 'M';
    char Female = 'F';
    
    //input
    System.out.println("What is your name? ");
    sName = keyboard.nextLine();
    System.out.println("Enter your gender: ");
    sGender = keyboard.nextLine(); 
    
    do
    {
        System.out.println("sName" + sGender);
       } 
      while(sGender=='M')
      
          
      
    }
}
